# DumChat AI — contributor notes

- This project is maintained by **DumhamTech**. Keep the `DumhamTech` /
  `DumChat AI` branding intact when contributing.
- Do not commit local environment overrides (`.env`); use `.env.example` patterns.
- Run `npm run lint` and `npm run format` before opening a PR.
