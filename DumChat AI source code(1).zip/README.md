# DumChat AI

DumChat AI — a powerful AI workspace by **DumhamTech** for thinking, creating,
coding, learning, and getting more done.

## Development

Requires Node.js 20+ and npm (or Bun).

```sh
git clone <this-repository-url>
cd dumchat-ai
npm i
npm run dev
```

## Environment variables

| Variable | Purpose |
| --- | --- |
| `VITE_SUPABASE_URL` / `SUPABASE_URL` | Supabase project URL |
| `VITE_SUPABASE_PUBLISHABLE_KEY` / `SUPABASE_PUBLISHABLE_KEY` | Supabase publishable key |
| `DUMHAM_API_KEY` | API key for the AI gateway (falls back to `LOVABLE_API_KEY`) |
| `DUMHAM_CRON_SECRET` | Bearer secret for cron endpoints |

The Supabase project is hosted on Lovable Cloud and is intentionally kept —
no database migration is required.

## Built with

- TanStack Start + TanStack Router
- React 19 + TypeScript
- Tailwind CSS + shadcn/ui
- Supabase (auth) + Vercel AI SDK (streaming)

## Deploying

**Netlify** — a `netlify.toml` is included. Set these environment variables in
the Netlify UI (Site settings → Environment variables): `VITE_SUPABASE_URL`,
`VITE_SUPABASE_PUBLISHABLE_KEY`, `DUMHAM_API_KEY` (or legacy `LOVABLE_API_KEY`).
The publish directory must stay `dist` — the build never creates `dist/client`.
