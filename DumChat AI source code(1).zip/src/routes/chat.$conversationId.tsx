import { useChat } from "@ai-sdk/react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { DefaultChatTransport, type UIMessage } from "ai";
import {
  Check,
  Code2,
  Copy,
  FileText,
  GraduationCap,
  Lightbulb,
  Paperclip,
  RefreshCcw,
  Search,
  ThumbsDown,
  ThumbsUp,
} from "lucide-react";
import { useCallback, useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import {
  Conversation,
  ConversationContent,
  ConversationEmptyState,
  ConversationScrollButton,
} from "@/components/ai-elements/conversation";
import {
  Message,
  MessageAction,
  MessageActions,
  MessageContent,
  MessageResponse,
} from "@/components/ai-elements/message";
import {
  PromptInput,
  PromptInputButton,
  PromptInputFooter,
  PromptInputSubmit,
  PromptInputTextarea,
  PromptInputTools,
  usePromptInputAttachments,
} from "@/components/ai-elements/prompt-input";
import { Reasoning, ReasoningContent, ReasoningTrigger } from "@/components/ai-elements/reasoning";
import { Shimmer } from "@/components/ai-elements/shimmer";
import { WorkspaceShell } from "@/components/workspace-shell";
import { Button } from "@/components/ui/button";
import { TooltipProvider } from "@/components/ui/tooltip";
import {
  chatStorage,
  createConversation,
  messageText,
  newId,
  titleFromMessage,
  type ConversationRecord,
} from "@/lib/chat-storage";

export const Route = createFileRoute("/chat/$conversationId")({
  head: () => ({
    meta: [
      { title: "Chat — DumChat AI" },
      {
        name: "description",
        content: "Think, create, code, learn, and solve problems with DumChat AI.",
      },
      { property: "og:title", content: "Chat — DumChat AI" },
      { property: "og:description", content: "Your ideas, amplified by AI." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ChatPage,
});

const suggestions = [
  {
    label: "Research",
    prompt: "Research a topic and give me a clear, balanced overview",
    icon: Search,
  },
  { label: "Code", prompt: "Help me build or debug a piece of code", icon: Code2 },
  {
    label: "Create",
    prompt: "Help me turn an idea into compelling written content",
    icon: Lightbulb,
  },
  { label: "Analyze", prompt: "Analyze a complex problem step by step", icon: FileText },
  {
    label: "Learn",
    prompt: "Teach me a difficult concept in a simple, memorable way",
    icon: GraduationCap,
  },
];

function AttachmentButton() {
  const attachments = usePromptInputAttachments();
  return (
    <PromptInputButton
      aria-label="Attach image or document"
      tooltip="Attach image or document"
      onClick={() => attachments.openFileDialog()}
    >
      <Paperclip />
    </PromptInputButton>
  );
}

function ChatPage() {
  const { conversationId } = Route.useParams();
  const navigate = useNavigate();
  const recordRef = useRef<ConversationRecord>(
    chatStorage.conversations().find((item) => item.id === conversationId) ??
      createConversation(conversationId),
  );
  const [draft, setDraft] = useState("");
  const [error, setError] = useState("");
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const transport = useMemo(() => new DefaultChatTransport({ api: "/api/chat" }), []);

  const persist = useCallback(
    (messages: UIMessage[]) => {
      const all = chatStorage.conversations();
      const current = recordRef.current;
      const firstUser = messages.find((message) => message.role === "user");
      const updated: ConversationRecord = {
        ...current,
        title:
          current.title === "New conversation" && firstUser
            ? titleFromMessage(messageText(firstUser))
            : current.title,
        updatedAt: new Date().toISOString(),
        messages,
      };
      recordRef.current = updated;
      chatStorage.saveConversations([updated, ...all.filter((item) => item.id !== conversationId)]);
      window.dispatchEvent(new Event("dumchat:conversations"));
    },
    [conversationId],
  );

  const { messages, sendMessage, regenerate, status, stop } = useChat({
    id: conversationId,
    messages: recordRef.current.messages,
    transport,
    onFinish: ({ messages: finished }) => persist(finished),
    onError: (chatError) => {
      setError(chatError.message || "Something went wrong while generating this response.");
    },
  });
  const busy = status === "submitted" || status === "streaming";

  const submit = async ({
    text,
    files,
  }: {
    text: string;
    files: Array<{ url: string; mediaType?: string; filename?: string }>;
  }) => {
    const clean = text.trim();
    if ((!clean && files.length === 0) || busy) return;
    setError("");
    const nextFiles = files.map((file) => ({
      type: "file" as const,
      url: file.url,
      mediaType: file.mediaType ?? "application/octet-stream",
      ...(file.filename ? { filename: file.filename } : {}),
    }));
    try {
      await sendMessage({ text: clean, files: nextFiles });
      setDraft("");
      if (files.length) {
        const existing = chatStorage.files();
        chatStorage.saveFiles([
          ...files.map((file) => ({
            id: newId(),
            name: file.filename ?? "Untitled file",
            type: file.mediaType ?? "File",
            size: Math.round((file.url.length * 3) / 4),
            uploadedAt: new Date().toISOString(),
            conversationId,
          })),
          ...existing,
        ]);
      }
    } catch (sendError) {
      const message =
        sendError instanceof Error
          ? sendError.message
          : "Something went wrong while generating this response.";
      setError(message);
      throw sendError;
    }
  };

  const copy = async (message: UIMessage) => {
    await navigator.clipboard.writeText(messageText(message));
    setCopiedId(message.id);
    window.setTimeout(() => setCopiedId(null), 1400);
  };

  return (
    <TooltipProvider>
      <WorkspaceShell
        activeId={conversationId}
        title={recordRef.current.title}
        actions={
          <Button variant="outline" size="sm" onClick={() => void navigate({ to: "/" })}>
            New chat
          </Button>
        }
      >
        <div className="flex h-full min-h-0 flex-col">
          <Conversation className="min-h-0">
            <ConversationContent className="mx-auto w-full max-w-3xl gap-7 px-4 pb-32 pt-8 sm:px-6">
              {messages.length === 0 ? (
                <ConversationEmptyState className="min-h-[56vh] justify-center p-0">
                  <div className="w-full text-left">
                    <p className="text-sm font-medium text-primary">DumChat AI</p>
                    <h2 className="mt-3 text-4xl font-semibold leading-tight sm:text-6xl">
                      Your ideas.
                      <br />
                      <span className="text-gradient">Amplified by AI.</span>
                    </h2>
                    <p className="mt-5 max-w-xl text-base leading-7 text-muted-foreground">
                      Ask questions, solve problems, write, code, analyze, research, and create.
                    </p>
                    <div className="mt-9 grid grid-cols-2 gap-2 sm:grid-cols-5">
                      {suggestions.map(({ label, prompt, icon: Icon }) => (
                        <Button
                          key={label}
                          className="h-auto justify-start gap-2 py-3"
                          variant="outline"
                          onClick={() => setDraft(prompt)}
                        >
                          <Icon className="size-4 text-primary" />
                          {label}
                        </Button>
                      ))}
                    </div>
                  </div>
                </ConversationEmptyState>
              ) : (
                messages.map((message, index) => {
                  const text = messageText(message);
                  const reasoning = message.parts
                    .filter((part) => part.type === "reasoning")
                    .map((part) => part.text)
                    .join("\n");
                  const lastAssistant =
                    message.role === "assistant" && index === messages.length - 1;
                  return (
                    <Message from={message.role} key={message.id}>
                      <MessageContent>
                        {message.role === "assistant" && reasoning && (
                          <Reasoning isStreaming={busy && lastAssistant}>
                            <ReasoningTrigger />
                            <ReasoningContent>{reasoning}</ReasoningContent>
                          </Reasoning>
                        )}
                        <MessageResponse isAnimating={busy && lastAssistant}>
                          {text}
                        </MessageResponse>
                      </MessageContent>
                      {message.role === "assistant" && text && (
                        <MessageActions className="opacity-100 sm:opacity-0 sm:transition-opacity sm:group-hover:opacity-100">
                          <MessageAction tooltip="Copy response" onClick={() => void copy(message)}>
                            {copiedId === message.id ? <Check /> : <Copy />}
                          </MessageAction>
                          {lastAssistant && (
                            <MessageAction
                              tooltip="Regenerate response"
                              onClick={() => {
                                setError("");
                                void regenerate();
                              }}
                            >
                              <RefreshCcw />
                            </MessageAction>
                          )}
                          <MessageAction
                            tooltip="Helpful"
                            onClick={() => toast.success("Thanks for the feedback")}
                          >
                            <ThumbsUp />
                          </MessageAction>
                          <MessageAction
                            tooltip="Not helpful"
                            onClick={() => toast("Feedback noted")}
                          >
                            <ThumbsDown />
                          </MessageAction>
                        </MessageActions>
                      )}
                    </Message>
                  );
                })
              )}
              {status === "submitted" && (
                <Shimmer className="text-sm">DumChat is thinking…</Shimmer>
              )}
              {error && (
                <div className="rounded-md border border-destructive/30 bg-destructive/10 p-4 text-sm">
                  <p>Something went wrong while generating this response.</p>
                  <p className="mt-1 text-xs text-muted-foreground">{error}</p>
                  <Button
                    className="mt-3"
                    size="sm"
                    variant="outline"
                    onClick={() => {
                      setError("");
                      void regenerate();
                    }}
                  >
                    Retry
                  </Button>
                </div>
              )}
            </ConversationContent>
            <ConversationScrollButton />
          </Conversation>
          <div className="composer-wrap shrink-0 px-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] sm:px-6">
            <div className="mx-auto max-w-3xl">
              <PromptInput
                accept="image/png,image/jpeg,image/webp,application/pdf,text/plain,text/markdown"
                maxFiles={4}
                maxFileSize={10 * 1024 * 1024}
                onError={(issue) => toast.error(issue.message)}
                onSubmit={submit}
              >
                <PromptInputTextarea
                  aria-label="Message DumChat AI"
                  maxLength={12000}
                  placeholder="Ask DumChat anything…"
                  value={draft}
                  onChange={(event) => setDraft(event.target.value)}
                />
                <PromptInputFooter>
                  <PromptInputTools>
                    <AttachmentButton />
                    <span className="hidden text-xs text-muted-foreground sm:inline">
                      Enter to send · Shift+Enter for a new line
                    </span>
                  </PromptInputTools>
                  <PromptInputSubmit
                    disabled={!busy && !draft.trim()}
                    status={status}
                    onStop={stop}
                  />
                </PromptInputFooter>
              </PromptInput>
              <p className="mt-2 text-center text-[11px] text-muted-foreground">
                DumChat can make mistakes. Check important information.
              </p>
            </div>
          </div>
        </div>
      </WorkspaceShell>
    </TooltipProvider>
  );
}
