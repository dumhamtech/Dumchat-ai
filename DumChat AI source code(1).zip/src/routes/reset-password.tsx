import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { BrandMark } from "@/components/brand-mark";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
export const Route = createFileRoute("/reset-password")({
  head: () => ({
    meta: [
      { title: "Reset password — DumChat AI" },
      { name: "description", content: "Reset your DumChat AI password." },
      { property: "og:title", content: "Reset password — DumChat AI" },
      { property: "og:description", content: "Recover access to DumChat AI." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ResetPassword,
});
function ResetPassword() {
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);
  const send = async () => {
    setLoading(true);
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/auth`,
    });
    setLoading(false);
    if (error) toast.error(error.message);
    else toast.success("Password reset instructions sent.");
  };
  return (
    <main className="auth-page">
      <div className="auth-panel">
        <BrandMark />
        <h1 className="mt-10 text-3xl font-semibold">Reset your password</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          We’ll send a secure recovery link to your email.
        </p>
        <div className="mt-8 space-y-2">
          <Label htmlFor="reset-email">Email</Label>
          <Input
            id="reset-email"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </div>
        <Button className="mt-5 w-full" disabled={loading || !email} onClick={() => void send()}>
          {loading ? "Sending…" : "Send recovery link"}
        </Button>
        <Link to="/auth" className="mt-6 block text-center text-sm text-primary hover:underline">
          Back to sign in
        </Link>
      </div>
    </main>
  );
}
