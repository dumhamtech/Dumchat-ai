import { createFileRoute } from "@tanstack/react-router";
import { Laptop, LogOut, Moon, Save, Sun } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { WorkspaceShell } from "@/components/workspace-shell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
export const Route = createFileRoute("/settings")({
  head: () => ({
    meta: [
      { title: "Settings — DumChat AI" },
      { name: "description", content: "Manage your DumChat AI account and preferences." },
      { property: "og:title", content: "Settings — DumChat AI" },
      { property: "og:description", content: "DumChat account and experience settings." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: SettingsPage,
});
type Theme = "dark" | "light" | "system";
function SettingsPage() {
  const [theme, setTheme] = useState<Theme>(() =>
    typeof window === "undefined"
      ? "dark"
      : ((window.localStorage.getItem("dumchat.theme") as Theme | null) ?? "dark"),
  );
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [userId, setUserId] = useState("");
  const [style, setStyle] = useState("balanced");
  useEffect(() => {
    void supabase.auth.getUser().then(async ({ data }) => {
      if (!data.user) return;
      setUserId(data.user.id);
      setEmail(data.user.email ?? "");
      const result = await supabase
        .from("profiles")
        .select("display_name,response_style")
        .eq("id", data.user.id)
        .maybeSingle();
      if (result.data) {
        setName(result.data.display_name);
        setStyle(result.data.response_style);
      }
    });
  }, []);
  useEffect(() => {
    const dark =
      theme === "dark" ||
      (theme === "system" && window.matchMedia("(prefers-color-scheme: dark)").matches);
    document.documentElement.classList.toggle("dark", dark);
    window.localStorage.setItem("dumchat.theme", theme);
  }, [theme]);
  const save = async () => {
    if (!userId) {
      toast("Sign in to save account settings");
      return;
    }
    const { error } = await supabase
      .from("profiles")
      .update({ display_name: name.trim(), response_style: style })
      .eq("id", userId);
    if (error) toast.error(error.message);
    else toast.success("Settings saved");
  };
  return (
    <WorkspaceShell title="Settings">
      <div className="mx-auto max-w-3xl p-5 sm:p-10">
        <p className="text-sm text-primary">Preferences</p>
        <h2 className="mt-2 text-3xl font-semibold">Settings</h2>
        <section className="settings-section">
          <h3>Appearance</h3>
          <p>Choose how DumChat looks on this device.</p>
          <div className="mt-5 grid grid-cols-3 gap-2">
            {(
              [
                { key: "dark", label: "Dark", icon: Moon },
                { key: "light", label: "Light", icon: Sun },
                { key: "system", label: "System", icon: Laptop },
              ] as const
            ).map(({ key, label, icon: Icon }) => (
              <Button
                key={key}
                variant={theme === key ? "default" : "outline"}
                onClick={() => setTheme(key)}
              >
                <Icon />
                {label}
              </Button>
            ))}
          </div>
        </section>
        <section className="settings-section">
          <h3>Account</h3>
          <p>Your profile is stored securely when you sign in.</p>
          <div className="mt-5 grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="display-name">Display name</Label>
              <Input
                id="display-name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Sign in to manage"
                disabled={!userId}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="account-email">Email</Label>
              <Input id="account-email" value={email} disabled />
            </div>
          </div>
        </section>
        <section className="settings-section">
          <h3>AI response style</h3>
          <p>Set your preferred level of detail.</p>
          <div className="mt-5 flex flex-wrap gap-2">
            {["concise", "balanced", "detailed"].map((value) => (
              <Button
                key={value}
                className="capitalize"
                variant={style === value ? "default" : "outline"}
                onClick={() => setStyle(value)}
              >
                {value}
              </Button>
            ))}
          </div>
        </section>
        <section className="settings-section">
          <h3>Privacy & storage</h3>
          <p>
            Conversation history, projects, and library metadata stay in this browser. They do not
            sync across devices. Your account profile is stored securely in DumChat’s backend.
          </p>
        </section>
        <section className="settings-section">
          <h3>About</h3>
          <p>
            DumChat AI by DumhamTech · Version 1.0
            <br />
            Where Tech Meets Excellence.
          </p>
        </section>
        <div className="mt-8 flex flex-wrap gap-2">
          <Button onClick={() => void save()}>
            <Save />
            Save settings
          </Button>
          {userId && (
            <Button
              variant="outline"
              onClick={() =>
                void supabase.auth.signOut().then(() => {
                  toast.success("Signed out");
                  window.location.href = "/";
                })
              }
            >
              <LogOut />
              Sign out
            </Button>
          )}
        </div>
      </div>
    </WorkspaceShell>
  );
}
