import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { Eye, EyeOff } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { BrandMark } from "@/components/brand-mark";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { dumham } from "@/integrations/dumham";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Sign in — DumChat AI" },
      { name: "description", content: "Sign in or create your DumChat AI account." },
      { property: "og:title", content: "Sign in — DumChat AI" },
      { property: "og:description", content: "Access your DumChat AI account." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [show, setShow] = useState(false);
  const [loading, setLoading] = useState(false);
  const run = async (mode: "signin" | "signup") => {
    setLoading(true);
    const result =
      mode === "signin"
        ? await supabase.auth.signInWithPassword({ email, password })
        : await supabase.auth.signUp({
            email,
            password,
            options: { data: { display_name: name.trim() } },
          });
    setLoading(false);
    if (result.error) {
      toast.error(result.error.message);
      return;
    }
    if (mode === "signup" && !result.data.session) {
      toast.success("Check your email to confirm your account.");
      return;
    }
    toast.success(mode === "signin" ? "Welcome back" : "Account created");
    await navigate({ to: "/" });
  };
  const google = async () => {
    setLoading(true);
    const { error } = await dumham.auth.signInWithOAuth("google", window.location.origin);
    setLoading(false);
    if (error) toast.error(error.message);
  };
  return (
    <main className="auth-page">
      <div className="auth-panel">
        <Link to="/">
          <BrandMark />
        </Link>
        <div className="mt-10">
          <h1 className="text-3xl font-semibold">Welcome to DumChat</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Think faster. Create better. Build anything.
          </p>
        </div>
        <Button
          className="mt-8 w-full"
          variant="outline"
          onClick={() => void google()}
          disabled={loading}
        >
          <span className="text-base font-semibold">G</span>Continue with Google
        </Button>
        <div className="my-6 flex items-center gap-3 text-xs text-muted-foreground">
          <span className="h-px flex-1 bg-border" />
          or continue with email
          <span className="h-px flex-1 bg-border" />
        </div>
        <Tabs defaultValue="signin">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="signin">Sign in</TabsTrigger>
            <TabsTrigger value="signup">Create account</TabsTrigger>
          </TabsList>
          <TabsContent value="signin">
            <AuthFields
              email={email}
              password={password}
              show={show}
              onEmail={setEmail}
              onPassword={setPassword}
              onShow={() => setShow(!show)}
            />
            <div className="mt-3 text-right">
              <Link to="/reset-password" className="text-xs text-primary hover:underline">
                Forgot password?
              </Link>
            </div>
            <Button
              className="mt-5 w-full"
              disabled={loading || !email || !password}
              onClick={() => void run("signin")}
            >
              {loading ? "Signing in…" : "Sign in"}
            </Button>
          </TabsContent>
          <TabsContent value="signup">
            <div className="mt-5 space-y-2">
              <Label htmlFor="name">Display name</Label>
              <Input
                id="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                autoComplete="name"
              />
            </div>
            <AuthFields
              email={email}
              password={password}
              show={show}
              onEmail={setEmail}
              onPassword={setPassword}
              onShow={() => setShow(!show)}
            />
            <Button
              className="mt-5 w-full"
              disabled={loading || !name.trim() || !email || password.length < 8}
              onClick={() => void run("signup")}
            >
              {loading ? "Creating account…" : "Create account"}
            </Button>
            <p className="mt-3 text-xs text-muted-foreground">
              Use at least 8 characters. You’ll confirm your email before signing in.
            </p>
          </TabsContent>
        </Tabs>
        <p className="mt-8 text-center text-xs text-muted-foreground">
          By continuing, you agree to use DumChat responsibly.
        </p>
      </div>
    </main>
  );
}
function AuthFields({
  email,
  password,
  show,
  onEmail,
  onPassword,
  onShow,
}: {
  email: string;
  password: string;
  show: boolean;
  onEmail: (value: string) => void;
  onPassword: (value: string) => void;
  onShow: () => void;
}) {
  return (
    <div className="mt-5 space-y-4">
      <div className="space-y-2">
        <Label htmlFor="email">Email</Label>
        <Input
          id="email"
          type="email"
          autoComplete="email"
          value={email}
          onChange={(e) => onEmail(e.target.value)}
        />
      </div>
      <div className="space-y-2">
        <Label htmlFor="password">Password</Label>
        <div className="relative">
          <Input
            id="password"
            type={show ? "text" : "password"}
            autoComplete="current-password"
            value={password}
            onChange={(e) => onPassword(e.target.value)}
            className="pr-10"
          />
          <Button
            className="absolute right-1 top-1"
            type="button"
            size="icon-sm"
            variant="ghost"
            aria-label={show ? "Hide password" : "Show password"}
            onClick={onShow}
          >
            {show ? <EyeOff /> : <Eye />}
          </Button>
        </div>
      </div>
    </div>
  );
}
