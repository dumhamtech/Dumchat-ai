import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import {
  ArrowRight,
  BrainCircuit,
  Code2,
  FileSearch,
  LockKeyhole,
  Menu,
  PenTool,
  ShieldCheck,
  X,
} from "lucide-react";
import { useState } from "react";
import { BrandMark } from "@/components/brand-mark";
import { Button } from "@/components/ui/button";
import { chatStorage, createConversation } from "@/lib/chat-storage";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "DumChat AI — Your Ideas, Amplified by AI" },
      {
        name: "description",
        content:
          "DumChat AI is a powerful AI workspace by DumhamTech for thinking, creating, coding, learning and getting more done.",
      },
      { property: "og:title", content: "DumChat AI — Your Ideas, Amplified by AI" },
      { property: "og:description", content: "A powerful AI workspace by DumhamTech." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const start = async () => {
    const conversation = createConversation();
    chatStorage.saveConversations([conversation, ...chatStorage.conversations()]);
    await navigate({ to: "/chat/$conversationId", params: { conversationId: conversation.id } });
  };
  return (
    <main className="landing-page">
      <header className="landing-nav">
        <Link to="/">
          <BrandMark />
        </Link>
        <nav className={open ? "landing-links open" : "landing-links"}>
          <a href="#capabilities" onClick={() => setOpen(false)}>
            Capabilities
          </a>
          <a href="#experience" onClick={() => setOpen(false)}>
            Experience
          </a>
          <a href="#security" onClick={() => setOpen(false)}>
            Trust
          </a>
          <Link to="/auth" onClick={() => setOpen(false)}>
            Sign in
          </Link>
          <Button onClick={() => void start()}>
            Start chatting <ArrowRight />
          </Button>
        </nav>
        <Button
          className="sm:hidden"
          size="icon"
          variant="ghost"
          aria-label="Toggle menu"
          onClick={() => setOpen(!open)}
        >
          {open ? <X /> : <Menu />}
        </Button>
      </header>
      <section className="landing-hero">
        <div className="hero-light" />
        <div className="relative z-10 mx-auto max-w-6xl px-5">
          <p className="eyebrow">Intelligence, built for momentum</p>
          <h1>
            DumChat AI
            <br />
            <span className="text-gradient">Your ideas. Amplified by AI.</span>
          </h1>
          <p className="hero-copy">
            A powerful AI workspace by DumhamTech to help you think faster, create better, and build
            anything.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Button size="lg" onClick={() => void start()}>
              Start chatting <ArrowRight />
            </Button>
            <Button
              size="lg"
              variant="outline"
              onClick={() =>
                document.querySelector("#capabilities")?.scrollIntoView({ behavior: "smooth" })
              }
            >
              Explore DumChat
            </Button>
          </div>
        </div>
        <div className="hero-console">
          <div className="console-bar">
            <span />
            <span />
            <span />
            <small>DumChat Intelligence</small>
          </div>
          <div className="console-body">
            <p className="console-user">Turn this rough product idea into a clear launch plan.</p>
            <div className="console-answer">
              <BrandMark compact />
              <div>
                <strong>Here’s a focused path from idea to launch.</strong>
                <p>
                  I’ll structure the product, audience, proof points, and first measurable
                  milestone—then turn each into an actionable workstream.
                </p>
                <div className="console-steps">
                  <span>01 · Position</span>
                  <span>02 · Prototype</span>
                  <span>03 · Validate</span>
                  <span>04 · Launch</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section id="capabilities" className="landing-section">
        <div className="section-heading">
          <p className="eyebrow">Dumham Intelligence</p>
          <h2>One workspace. Five ways to move forward.</h2>
          <p>
            From the first question to the finished work, DumChat adapts to what you’re trying to
            accomplish.
          </p>
        </div>
        <div className="capability-grid">
          {[
            [
              BrainCircuit,
              "Reason",
              "Untangle complex decisions with structured, considered thinking.",
            ],
            [
              FileSearch,
              "Research",
              "Build useful overviews and identify the questions worth asking next.",
            ],
            [PenTool, "Create", "Shape ideas into clear writing, concepts, and finished drafts."],
            [Code2, "Code", "Plan, explain, write, and debug software with practical guidance."],
            [
              ShieldCheck,
              "Analyze",
              "Find patterns, compare options, and turn information into direction.",
            ],
          ].map(([Icon, title, copy]) => {
            const C = Icon as typeof BrainCircuit;
            return (
              <article key={String(title)}>
                <C />
                <h3>{String(title)}</h3>
                <p>{String(copy)}</p>
              </article>
            );
          })}
        </div>
      </section>
      <section id="experience" className="landing-band">
        <div className="mx-auto grid max-w-6xl gap-12 px-5 lg:grid-cols-2 lg:items-center">
          <div>
            <p className="eyebrow">Designed for real work</p>
            <h2>A quieter, sharper way to collaborate with AI.</h2>
            <p>
              Readable answers, thoughtful reasoning, polished code, and conversation history that
              stays under your control.
            </p>
            <div className="feature-list">
              <span>
                <Code2 />
                Markdown and copy-ready code
              </span>
              <span>
                <FileSearch />
                Image and document context
              </span>
              <span>
                <BrainCircuit />
                Visible reasoning progress
              </span>
            </div>
          </div>
          <div className="experience-panel">
            <p className="text-xs text-muted-foreground">DUMCHAT / ACTIVE THREAD</p>
            <h3>Build a launch page that feels premium, not generic.</h3>
            <div className="experience-line" />
            <p>
              DumChat breaks the goal into brand direction, message hierarchy, interaction details,
              and a shippable implementation plan.
            </p>
            <div className="flex gap-2">
              <span>Strategy</span>
              <span>Design</span>
              <span>Build</span>
            </div>
          </div>
        </div>
      </section>
      <section id="security" className="landing-section trust-section">
        <LockKeyhole />
        <div>
          <p className="eyebrow">Privacy without theatre</p>
          <h2>Your account is protected. Your chat history stays in your browser.</h2>
          <p>
            DumChat accurately separates secure account data from local conversation history.
            Nothing is presented as private beyond what the architecture genuinely guarantees.
          </p>
        </div>
      </section>
      <section className="final-cta">
        <p className="eyebrow">Where Tech Meets Excellence.</p>
        <h2>Bring your next idea.</h2>
        <p>DumChat will help you make it clearer, stronger, and ready to move.</p>
        <Button size="lg" onClick={() => void start()}>
          Start chatting <ArrowRight />
        </Button>
      </section>
      <footer>
        <BrandMark />
        <p>© {new Date().getFullYear()} DumhamTech. Built for better thinking.</p>
      </footer>
    </main>
  );
}
