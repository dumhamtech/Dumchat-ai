import { createFileRoute } from "@tanstack/react-router";
import { convertToModelMessages, streamText, type UIMessage } from "ai";
import { z } from "zod";
import { createDumChatModel } from "@/lib/ai-gateway.server";
import { DUMHAMTECH_KNOWLEDGE } from "@/lib/brand-knowledge";

const BodySchema = z.object({ messages: z.array(z.unknown()).max(100) });

export const Route = createFileRoute("/api/chat")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const key = process.env["DUMHAM_API_KEY"] ?? process.env["LOVABLE_API_KEY"];
        if (!key) return Response.json({ message: "AI is not configured." }, { status: 401 });
        let parsed: z.infer<typeof BodySchema>;
        try {
          parsed = BodySchema.parse(await request.json());
        } catch {
          return Response.json({ message: "That request could not be read." }, { status: 400 });
        }
        const messages = parsed.messages as UIMessage[];
        const total = messages.reduce((sum, message) => sum + JSON.stringify(message).length, 0);
        if (!messages.length || total > 180_000)
          return Response.json(
            { message: "This conversation is too large to send." },
            { status: 400 },
          );
        try {
          const result = streamText({
            model: createDumChatModel(key),
            system: `You are DumChat AI by DumhamTech.

Answer quality rules:
- Give complete, well-structured, genuinely useful answers. Cover the important details, not just the surface. Use clear Markdown: headings, short paragraphs, bullet points, and code blocks where they help.
- Be accurate above all. Only state facts you are confident about. If you are unsure, say so plainly and explain what would be needed to verify it — never guess, exaggerate, or fill gaps with invented details.
- For numbers, dates, names, laws, medical/legal/financial topics, and current events: answer from reliable general knowledge, and clearly note when information may have changed or needs verification.
- Never claim tools, browsing, citations, sources, or actions you do not have. If you cannot verify something, say "I can't verify that" rather than presenting it as fact.
- When a question is ambiguous, briefly state your interpretation before answering, or ask one focused clarifying question.
- Keep the tone professional, confident, and helpful — thorough, not padded.

${DUMHAMTECH_KNOWLEDGE}`,
            messages: await convertToModelMessages(messages),
            abortSignal: request.signal,
            providerOptions: {
              openai: {
                forceReasoning: true,
                reasoningEffort: "medium",
                reasoningSummary: "auto",
                store: false,
                include: ["reasoning.encrypted_content"],
              },
            },
          });
          return result.toUIMessageStreamResponse({
            originalMessages: messages,
            sendReasoning: true,
          });
        } catch (error) {
          if (error instanceof Error && error.name === "AbortError")
            return new Response(null, { status: 499 });
          console.error("DumChat generation failed", error);
          return Response.json(
            { message: "Something went wrong while generating this response." },
            { status: 500 },
          );
        }
      },
    },
  },
});
