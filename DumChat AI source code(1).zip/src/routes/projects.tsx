import { createFileRoute } from "@tanstack/react-router";
import { FolderKanban, Plus } from "lucide-react";
import { useState } from "react";
import { WorkspaceShell } from "@/components/workspace-shell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { chatStorage, newId, type ChatProject } from "@/lib/chat-storage";

export const Route = createFileRoute("/projects")({
  head: () => ({
    meta: [
      { title: "Projects — DumChat AI" },
      { name: "description", content: "Organize DumChat AI conversations into projects." },
      { property: "og:title", content: "Projects — DumChat AI" },
      { property: "og:description", content: "Organize your AI work." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ProjectsPage,
});
function ProjectsPage() {
  const [projects, setProjects] = useState<ChatProject[]>(() => chatStorage.projects());
  const [name, setName] = useState("");
  const add = () => {
    const clean = name.trim();
    if (!clean) return;
    const next = [...projects, { id: newId(), name: clean, createdAt: new Date().toISOString() }];
    chatStorage.saveProjects(next);
    setProjects(next);
    setName("");
  };
  return (
    <WorkspaceShell title="Projects">
      <div className="mx-auto max-w-5xl p-5 sm:p-10">
        <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
          <div>
            <p className="text-sm text-primary">Workspace</p>
            <h2 className="mt-2 text-3xl font-semibold">Projects</h2>
            <p className="mt-2 text-muted-foreground">Group related conversations around a goal.</p>
          </div>
          <div className="flex gap-2">
            <Input
              value={name}
              onChange={(e) => setName(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") add();
              }}
              placeholder="Project name"
            />
            <Button onClick={add}>
              <Plus />
              Create
            </Button>
          </div>
        </div>
        {projects.length ? (
          <div className="mt-10 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {projects.map((project) => (
              <article key={project.id} className="surface-card p-5">
                <FolderKanban className="size-5 text-primary" />
                <h3 className="mt-5 font-medium">{project.name}</h3>
                <p className="mt-1 text-xs text-muted-foreground">
                  Created {new Date(project.createdAt).toLocaleDateString()}
                </p>
              </article>
            ))}
          </div>
        ) : (
          <div className="empty-panel mt-10">
            <FolderKanban />
            <h3>Projects, when you need them.</h3>
            <p>Organize your conversations into projects when you're ready.</p>
          </div>
        )}
      </div>
    </WorkspaceShell>
  );
}
