import { createFileRoute } from "@tanstack/react-router";
import { FileText, Library } from "lucide-react";
import { WorkspaceShell } from "@/components/workspace-shell";
import { chatStorage } from "@/lib/chat-storage";
export const Route = createFileRoute("/library")({
  head: () => ({
    meta: [
      { title: "Library — DumChat AI" },
      {
        name: "description",
        content: "Review documents and images used in your DumChat conversations.",
      },
      { property: "og:title", content: "Library — DumChat AI" },
      { property: "og:description", content: "Your local DumChat files." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: LibraryPage,
});
function LibraryPage() {
  const files = chatStorage.files();
  return (
    <WorkspaceShell title="Library">
      <div className="mx-auto max-w-5xl p-5 sm:p-10">
        <p className="text-sm text-primary">Workspace</p>
        <h2 className="mt-2 text-3xl font-semibold">Library</h2>
        <p className="mt-2 text-muted-foreground">Files you have shared in this browser.</p>
        {files.length ? (
          <div className="mt-10 divide-y divide-border border-y border-border">
            {files.map((file) => (
              <div className="flex items-center gap-4 py-4" key={file.id}>
                <FileText className="text-primary" />
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium">{file.name}</p>
                  <p className="text-xs text-muted-foreground">
                    {file.type} · {(file.size / 1024).toFixed(1)} KB ·{" "}
                    {new Date(file.uploadedAt).toLocaleDateString()}
                  </p>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="empty-panel mt-10">
            <Library />
            <h3>Your library is ready.</h3>
            <p>Upload a document or image in a chat to start analyzing it.</p>
          </div>
        )}
      </div>
    </WorkspaceShell>
  );
}
