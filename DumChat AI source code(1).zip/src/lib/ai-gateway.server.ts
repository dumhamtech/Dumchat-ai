import { createOpenAI } from "@ai-sdk/openai";

// The model is served through an OpenAI-compatible AI gateway.
// Override the endpoint with DUMHAM_AI_GATEWAY_URL if you self-host or migrate providers.
export function createDumChatModel(apiKey: string) {
  const provider = createOpenAI({
    baseURL: process.env["DUMHAM_AI_GATEWAY_URL"] ?? "https://ai.gateway.lovable.dev/v1",
    apiKey,
    // Header names are part of the upstream gateway protocol; renaming them
    // would break authentication.
    headers: { "Lovable-API-Key": apiKey, "X-Lovable-AIG-SDK": "vercel-ai-sdk" },
  });
  return provider.responses("openai/gpt-6-astra");
}
