import type { UIMessage } from "ai";

export type ChatProject = { id: string; name: string; createdAt: string };
export type LibraryFile = {
  id: string;
  name: string;
  type: string;
  size: number;
  uploadedAt: string;
  conversationId: string;
};
export type ConversationRecord = {
  id: string;
  title: string;
  createdAt: string;
  updatedAt: string;
  projectId: string | null;
  messages: UIMessage[];
};

const CONVERSATIONS_KEY = "dumchat.conversations.v1";
const PROJECTS_KEY = "dumchat.projects.v1";
const FILES_KEY = "dumchat.files.v1";

function read<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try {
    const value = window.localStorage.getItem(key);
    return value ? (JSON.parse(value) as T) : fallback;
  } catch {
    return fallback;
  }
}

function write<T>(key: string, value: T) {
  if (typeof window !== "undefined") window.localStorage.setItem(key, JSON.stringify(value));
}

export const chatStorage = {
  conversations: () => read<ConversationRecord[]>(CONVERSATIONS_KEY, []),
  projects: () => read<ChatProject[]>(PROJECTS_KEY, []),
  files: () => read<LibraryFile[]>(FILES_KEY, []),
  saveConversations: (value: ConversationRecord[]) => write(CONVERSATIONS_KEY, value),
  saveProjects: (value: ChatProject[]) => write(PROJECTS_KEY, value),
  saveFiles: (value: LibraryFile[]) => write(FILES_KEY, value),
};

export function newId() {
  return crypto.randomUUID();
}

export function createConversation(id: string = newId()): ConversationRecord {
  const now = new Date().toISOString();
  return {
    id,
    title: "New conversation",
    createdAt: now,
    updatedAt: now,
    projectId: null,
    messages: [],
  };
}

export function messageText(message: UIMessage) {
  return message.parts
    .filter((part) => part.type === "text")
    .map((part) => part.text)
    .join(" ");
}

export function titleFromMessage(value: string) {
  const clean = value.trim().replace(/\s+/g, " ");
  return clean.length > 46 ? `${clean.slice(0, 46).trim()}…` : clean || "New conversation";
}
