// Auth session storage for DumChat AI by DumhamTech.
// Standard localStorage persistence; no third-party editor brokering.
export function brokeredPreviewStorage() {
  if (typeof window === "undefined") return undefined;
  return localStorage;
}
