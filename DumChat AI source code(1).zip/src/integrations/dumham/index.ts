// DumhamTech authentication helpers (Supabase-native OAuth).
import { supabase } from "@/integrations/supabase/client";

export const dumham = {
  auth: {
    signInWithOAuth: (provider: "google", redirect_uri?: string) =>
      supabase.auth.signInWithOAuth({
        provider,
        options: { redirectTo: redirect_uri ?? window.location.origin },
      }),
  },
};
