import { Sparkles } from "lucide-react";

// Floating DumhamTech badge — the DumhamTech counterpart to a builder watermark.
export function DumhamBadge() {
  return (
    <a
      href="/"
      aria-label="Built by DumhamTech"
      className="fixed bottom-4 right-4 z-50 inline-flex items-center gap-1.5 rounded-full border border-border bg-card/90 px-3 py-1.5 text-xs font-medium text-muted-foreground shadow-lg backdrop-blur transition-colors hover:text-foreground"
    >
      <Sparkles className="size-3.5 text-primary" />
      Built by DumhamTech
    </a>
  );
}
