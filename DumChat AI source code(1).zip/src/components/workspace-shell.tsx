import { Menu, PanelLeftClose, PanelLeftOpen } from "lucide-react";
import { useState, type ReactNode } from "react";
import { AppSidebar } from "@/components/app-sidebar";
import { BrandMark } from "@/components/brand-mark";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTitle } from "@/components/ui/sheet";

export function WorkspaceShell({
  children,
  activeId,
  title,
  actions,
}: {
  children: ReactNode;
  activeId?: string | undefined;
  title: string;
  actions?: ReactNode;
}) {
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  return (
    <div className="flex h-dvh min-h-0 overflow-hidden bg-background">
      <div
        className={`hidden shrink-0 border-r border-sidebar-border transition-[width] duration-200 md:block ${collapsed ? "w-0 overflow-hidden" : "w-72"}`}
      >
        <AppSidebar activeId={activeId} />
      </div>
      <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
        <SheetContent side="left" className="w-[88vw] max-w-80 p-0">
          <SheetTitle className="sr-only">DumChat navigation</SheetTitle>
          <AppSidebar activeId={activeId} onNavigate={() => setMobileOpen(false)} />
        </SheetContent>
      </Sheet>
      <main className="flex min-w-0 flex-1 flex-col">
        <header className="flex h-16 shrink-0 items-center justify-between border-b border-border px-3 sm:px-5">
          <div className="flex min-w-0 items-center gap-2">
            <Button
              className="md:hidden"
              aria-label="Open navigation"
              size="icon"
              variant="ghost"
              onClick={() => setMobileOpen(true)}
            >
              <Menu />
            </Button>
            <Button
              className="hidden md:inline-flex"
              aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
              size="icon"
              variant="ghost"
              onClick={() => setCollapsed((value) => !value)}
            >
              {collapsed ? <PanelLeftOpen /> : <PanelLeftClose />}
            </Button>
            {collapsed && <BrandMark compact className="hidden md:flex" />}
            <h1 className="truncate text-sm font-medium">{title}</h1>
          </div>
          <div className="flex items-center gap-2">{actions}</div>
        </header>
        <div className="min-h-0 flex-1">{children}</div>
      </main>
    </div>
  );
}
