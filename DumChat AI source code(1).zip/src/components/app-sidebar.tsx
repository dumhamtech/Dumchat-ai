import { Link, useNavigate } from "@tanstack/react-router";
import {
  FolderKanban,
  Library,
  LogIn,
  MessageSquareText,
  MoreHorizontal,
  Plus,
  Search,
  Settings,
} from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { BrandMark } from "@/components/brand-mark";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  chatStorage,
  createConversation,
  messageText,
  type ConversationRecord,
} from "@/lib/chat-storage";

export function AppSidebar({
  activeId,
  onNavigate,
}: {
  activeId?: string | undefined;
  onNavigate?: (() => void) | undefined;
}) {
  const navigate = useNavigate();
  const [query, setQuery] = useState("");
  const [items, setItems] = useState<ConversationRecord[]>(() => chatStorage.conversations());
  useEffect(() => {
    const refresh = () => setItems(chatStorage.conversations());
    window.addEventListener("dumchat:conversations", refresh);
    return () => window.removeEventListener("dumchat:conversations", refresh);
  }, []);
  const visible = useMemo(() => {
    const q = query.trim().toLowerCase();
    return items
      .filter(
        (item) =>
          !q ||
          item.title.toLowerCase().includes(q) ||
          item.messages.some((m) => messageText(m).toLowerCase().includes(q)),
      )
      .sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
  }, [items, query]);

  const createNew = async () => {
    const conversation = createConversation();
    const next = [conversation, ...items];
    chatStorage.saveConversations(next);
    window.dispatchEvent(new Event("dumchat:conversations"));
    setItems(next);
    onNavigate?.();
    await navigate({ to: "/chat/$conversationId", params: { conversationId: conversation.id } });
  };

  const rename = (item: ConversationRecord) => {
    const title = window.prompt("Rename conversation", item.title)?.trim();
    if (!title) return;
    const next = items.map((entry) =>
      entry.id === item.id ? { ...entry, title, updatedAt: new Date().toISOString() } : entry,
    );
    chatStorage.saveConversations(next);
    window.dispatchEvent(new Event("dumchat:conversations"));
    setItems(next);
  };

  const remove = async (item: ConversationRecord) => {
    if (!window.confirm(`Delete “${item.title}”? This cannot be undone.`)) return;
    const next = items.filter((entry) => entry.id !== item.id);
    chatStorage.saveConversations(next);
    window.dispatchEvent(new Event("dumchat:conversations"));
    setItems(next);
    if (activeId === item.id) await createNew();
  };

  return (
    <aside className="flex h-full w-full flex-col bg-sidebar text-sidebar-foreground">
      <div className="flex h-16 items-center border-b border-sidebar-border px-4">
        <BrandMark />
      </div>
      <div className="space-y-3 px-3 py-4">
        <Button className="w-full justify-start" onClick={createNew}>
          <Plus />
          New chat
        </Button>
        <div className="relative">
          <Search className="absolute left-3 top-2.5 size-4 text-muted-foreground" />
          <Input
            aria-label="Search conversations"
            className="pl-9"
            placeholder="Search conversations"
            value={query}
            onChange={(event) => setQuery(event.target.value)}
          />
        </div>
      </div>
      <nav className="px-3" aria-label="Workspace">
        <Link to="/projects" onClick={onNavigate} className="sidebar-link">
          <FolderKanban />
          Projects
        </Link>
        <Link to="/library" onClick={onNavigate} className="sidebar-link">
          <Library />
          Library
        </Link>
      </nav>
      <div className="mt-5 px-4 text-[11px] font-medium uppercase text-muted-foreground">
        Recent chats
      </div>
      <div className="mt-2 min-h-0 flex-1 space-y-1 overflow-y-auto px-2">
        {visible.length ? (
          visible.map((item) => (
            <div
              className={`conversation-row ${activeId === item.id ? "active" : ""}`}
              key={item.id}
            >
              <Link
                to="/chat/$conversationId"
                params={{ conversationId: item.id }}
                onClick={onNavigate}
                className="min-w-0 flex-1 truncate px-2 py-2 text-sm"
              >
                <MessageSquareText className="mr-2 inline size-4" />
                {item.title}
              </Link>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button aria-label={`Actions for ${item.title}`} size="icon-sm" variant="ghost">
                    <MoreHorizontal />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem onSelect={() => rename(item)}>Rename</DropdownMenuItem>
                  <DropdownMenuItem className="text-destructive" onSelect={() => void remove(item)}>
                    Delete
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          ))
        ) : (
          <p className="px-3 py-8 text-center text-xs text-muted-foreground">
            {query ? "No conversations found." : "Your conversations will appear here."}
          </p>
        )}
      </div>
      <div className="border-t border-sidebar-border p-3">
        <Link to="/settings" onClick={onNavigate} className="sidebar-link">
          <Settings />
          Settings
        </Link>
        <Link to="/auth" onClick={onNavigate} className="sidebar-link">
          <LogIn />
          Account
        </Link>
      </div>
    </aside>
  );
}
