import { cn } from "@/lib/utils";

export function BrandMark({
  compact = false,
  className,
}: {
  compact?: boolean;
  className?: string;
}) {
  return (
    <div className={cn("flex items-center gap-3", className)}>
      <div className="brand-mark" aria-hidden="true">
        <span>D</span>
      </div>
      {!compact && (
        <div className="leading-none">
          <div className="text-[15px] font-semibold text-foreground">DumChat AI</div>
          <div className="mt-1 text-[10px] text-muted-foreground">by DumhamTech</div>
        </div>
      )}
    </div>
  );
}
